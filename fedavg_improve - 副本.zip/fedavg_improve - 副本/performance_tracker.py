# performance_tracker.py
import datetime
import time
import numpy as np
import psutil
import os
import csv
from typing import Dict, Any
import torch


def calculate_communication_overhead(selected_users, auxiliary_nodes, w_locals, w_glob):
    """
    计算实际通信开销（修正版）

    Args:
        selected_users: 选中的客户端列表
        auxiliary_nodes: 辅助节点列表
        w_locals: 客户端本地模型参数列表
        w_glob: 全局模型参数字典

    Returns:
        dict: 包含各类开销的字典（单位MB）
    """
    # 常量定义
    PROTOCOL_OVERHEAD_FACTOR = 1.05  # 5%协议开销
    VERIFICATION_MSG_SIZE = 512  # 字节（请求+响应）

    # 1. 计算单个模型参数大小
    def calc_param_size(params):
        if not params:
            return 0

        size_bytes = 0
        for param in params.values():
            if isinstance(param, torch.Tensor):
                size_bytes += param.nelement() * param.element_size()
            elif isinstance(param, np.ndarray):
                size_bytes += param.nbytes
            else:
                # 默认按float32处理
                size_bytes += np.prod(param.shape) * 4 if hasattr(param, 'shape') else 0
        return size_bytes

    # 2. 计算各项开销
    overhead = {
        'downlink_broadcast': 0.0,  # 服务器→客户端（广播）
        'uplink_models': 0.0,  # 客户端→服务器（模型上传）
        'verification': 0.0,  # 验证开销
        'total': 0.0  # 总开销
    }

    # 全局模型广播（下行）
    global_size = calc_param_size(w_glob)
    # 广播只需计算一次（非N*大小）
    overhead['downlink_broadcast'] = global_size / (1024 ** 2)  # MB

    # 客户端模型上传（上行）
    if w_locals:
        # 取第一个客户端模型作为基准（假设所有模型结构相同）
        client_model_size = calc_param_size(w_locals[0])
        overhead['uplink_models'] = (client_model_size * len(selected_users)) / (1024 ** 2)

    # 验证开销（双向）
    # 每个辅助节点与每个客户端交互：请求+响应
    verification_bytes = VERIFICATION_MSG_SIZE * len(auxiliary_nodes) * len(selected_users)
    overhead['verification'] = verification_bytes / (1024 ** 2)

    # 计算总开销（考虑网络协议开销）
    total_bytes = (overhead['downlink_broadcast'] + overhead['uplink_models'] + overhead['verification']) * 1024 ** 2
    overhead['total'] = (total_bytes * PROTOCOL_OVERHEAD_FACTOR) / (1024 ** 2)

    return overhead


class PerformanceTracker:
    def __init__(self, experiment_name: str):
        self.experiment_name = experiment_name
        self.csv_file = f"ourmodel_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.start_time = time.time()
        self.start_memory = self._get_memory_usage()
        self._init_csv()

    def _get_memory_usage(self):
        """获取峰值内存使用量(MB)"""
        process = psutil.Process(os.getpid())
        return process.memory_info().rss / 1024 / 1024

    def _init_csv(self):
        """初始化CSV文件"""
        headers = [
            'round', 'total_time', 'training_time', 'verification_time',
            'memory_usage', 'comm_total', 'accuracy', 'loss',
            'comm_downlink', 'comm_uplink', 'comm_verification'
        ]
        with open(self.csv_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)

    def start_round_monitoring(self):
        """开始一轮内存监控"""
        self.round_memory_samples = []  # 重置采样
        self._sample_memory()  # 开始采样

    def _sample_memory(self):
        """采样内存使用情况"""
        self.round_memory_samples.append(self._get_memory_usage())

    def get_round_avg_memory(self):
        """获取本轮平均内存使用量"""
        if not self.round_memory_samples:
            return self._get_memory_usage()
        return np.mean(self.round_memory_samples)

    def record_round_metrics(self, round_num: int, metrics: Dict[str, Any]):
        """记录每轮的性能指标"""
        # 在关键点进行内存采样
        self._sample_memory()

        avg_memory = self.get_round_avg_memory()

        # 获取通信开销详情
        comm_overhead = metrics.get('communication_overhead', {})

        row = [
            round_num,
            metrics.get('total_time', 0),
            metrics.get('training_time', 0),
            metrics.get('verification_time', 0),
            avg_memory,  # 使用轮次平均内存
            comm_overhead.get('total', 0),
            metrics.get('accuracy', 0),
            metrics.get('loss', 0),
            comm_overhead.get('downlink_broadcast', 0),
            comm_overhead.get('uplink_models', 0),
            comm_overhead.get('verification', 0)
        ]

        with open(self.csv_file, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(row)

    def get_current_metrics(self) -> Dict[str, float]:
        """获取当前性能指标"""
        return {
            'elapsed_time': time.time() - self.start_time,
            'memory_usage': self._get_memory_usage(),
            'memory_delta': self._get_memory_usage() - self.start_memory
        }