import datetime

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import PercentFormatter

import matplotlib

matplotlib.use('Agg')  # 设置为非交互式后端

# 设置中文字体 - 使用系统可用的字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'FangSong', 'KaiTi']  # 使用更常见的中文字体
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

from utils.vrf import VRFServer, VRFClient, select_clients_vrf_enhanced


class MaliciousNodeAnalyzer:
    def __init__(self, total_users=100, malicious_ratio=0.2,
                 selection_frac=0.2, total_rounds=50, manipulation_strength=0.5):
        """
        初始化恶意节点分析器（新增操纵场景）
        :param manipulation_strength: 恶意节点操纵强度（0-1，值越高操纵能力越强）
        """
        self.total_users = total_users
        self.malicious_ratio = malicious_ratio
        self.selection_frac = selection_frac
        self.total_rounds = total_rounds
        self.manipulation_strength = manipulation_strength  # 新增：操纵强度

        # 确定恶意节点和诚实节点
        self.malicious_users = set(np.random.choice(
            total_users, size=int(total_users * malicious_ratio), replace=False))
        self.honest_users = set(range(total_users)) - self.malicious_users

        # 每轮选择的客户端数量
        self.selected_per_round = int(total_users * selection_frac)
        # 理论上每轮应选择的恶意节点数量
        self.theoretical_malicious_per_round = int(
            self.selected_per_round * malicious_ratio)

        # 存储实验数据（新增操纵场景标记）
        self.vrf_data = {
            "selected": [], "malicious_in": [], "ratio_deviation": [], "consecutive": []
        }
        self.baseline_data = {
            "selected": [], "malicious_in": [], "ratio_deviation": [], "consecutive": []
        }

        # 记录上一轮选中的恶意节点
        self.last_vrf_malicious = set()
        self.last_baseline_malicious = set()

        # 新增：为传统随机机制准备操纵权重（恶意节点会篡改自身入选概率）
        self.baseline_weights = np.ones(total_users)

    def select_vrf_clients(self):
        """VRF选择机制（抗操纵性核心：选择过程可验证，恶意节点无法篡改）"""
        vrf_server = VRFServer()
        clients = [VRFClient(f"client_{i}") for i in range(self.total_users)]
        for c in clients:
            vrf_server.register_client(c)

        # 注意：这里的 iter 参数未定义，需要修复
        idxs_users = select_clients_vrf_enhanced(vrf_server, clients, 0, self.selection_frac)

        return idxs_users

    def select_baseline_clients(self):
        """传统随机选择机制（易被操纵：恶意节点可篡改自身权重）"""
        # 新增：恶意节点主动操纵选择权重
        # 原理：恶意节点通过篡改传统随机的选择概率，提高自身入选率
        for user in self.malicious_users:
            # 操纵强度越高，恶意节点的权重提升越多（最高为诚实节点的2倍）
            self.baseline_weights[user] = 1 + self.manipulation_strength  # 诚实节点权重为1
        for user in self.honest_users:
            self.baseline_weights[user] = 1  # 诚实节点权重不变
        self.baseline_weights = self.baseline_weights / np.sum(self.baseline_weights)  # 归一化

        # 传统随机选择（此时权重已被恶意节点篡改）
        selected = np.random.choice(
            self.total_users, size=self.selected_per_round,
            replace=False, p=self.baseline_weights)
        return selected

    def run_simulation(self):
        """运行模拟实验（包含恶意节点操纵场景）"""
        for round_num in range(self.total_rounds):
            # VRF组（不受操纵影响）
            vrf_selected = self.select_vrf_clients()
            self.vrf_data["selected"].append(vrf_selected)
            vrf_malicious = set(vrf_selected) & self.malicious_users
            self.vrf_data["malicious_in"].append(len(vrf_malicious))
            self.vrf_data["ratio_deviation"].append(
                abs(len(vrf_malicious) - self.theoretical_malicious_per_round) / self.selected_per_round)
            self.vrf_data["consecutive"].append(
                len(vrf_malicious & self.last_vrf_malicious))
            self.last_vrf_malicious = vrf_malicious

            # 传统随机组（受操纵影响）
            baseline_selected = self.select_baseline_clients()
            self.baseline_data["selected"].append(baseline_selected)
            baseline_malicious = set(baseline_selected) & self.malicious_users
            self.baseline_data["malicious_in"].append(len(baseline_malicious))
            self.baseline_data["ratio_deviation"].append(
                abs(len(baseline_malicious) - self.theoretical_malicious_per_round) / self.selected_per_round)
            self.baseline_data["consecutive"].append(
                len(baseline_malicious & self.last_baseline_malicious))
            self.last_baseline_malicious = baseline_malicious

    def plot_malicious_count(self):
        plt.figure(figsize=(12, 6))
        rounds = range(1, self.total_rounds + 1)
        plt.plot(rounds, self.vrf_data["malicious_in"], 'b-', marker='o',
                 label=f'VRF机制 (平均={np.mean(self.vrf_data["malicious_in"]):.2f})')
        plt.plot(rounds, self.baseline_data["malicious_in"], 'r-', marker='s',
                 label=f'传统随机（受操纵） (平均={np.mean(self.baseline_data["malicious_in"]):.2f})')
        plt.axhline(y=self.theoretical_malicious_per_round, color='g', linestyle='--',
                    label=f'理论值 ({self.theoretical_malicious_per_round})')
        plt.title('恶意节点操纵场景下的入选数量对比')
        plt.xlabel('训练轮次')
        plt.ylabel('恶意节点数量')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_manipulated_malicious_count{self.total_rounds}_{self.total_users}.svg', dpi=300, format="svg")
        # 注释掉 plt.show()，因为使用的是非交互式后端
        plt.close()  # 关闭图形以释放内存

    def plot_ratio_deviation(self):
        plt.figure(figsize=(12, 6))
        rounds = range(1, self.total_rounds + 1)
        plt.plot(rounds, self.vrf_data["ratio_deviation"], 'b-', marker='o',
                 label=f'VRF机制 (平均偏差={np.mean(self.vrf_data["ratio_deviation"]) * 100:.2f}%)')
        plt.plot(rounds, self.baseline_data["ratio_deviation"], 'r-', marker='s',
                 label=f'传统随机（受操纵） (平均偏差={np.mean(self.baseline_data["ratio_deviation"]) * 100:.2f}%)')
        plt.title('恶意节点操纵场景下的比例偏差对比')
        plt.xlabel('训练轮次')
        plt.ylabel('偏差比例')
        plt.gca().yaxis.set_major_formatter(PercentFormatter(xmax=1.0))
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_manipulated_deviation{self.total_rounds}_{self.total_users}.svg', dpi=300, format="svg")
        # 注释掉 plt.show()
        plt.close()  # 关闭图形以释放内存

    def plot_consecutive_analysis(self):
        plt.figure(figsize=(12, 6))
        vrf_consec_counts = pd.Series(self.vrf_data["consecutive"]).value_counts().sort_index()
        baseline_consec_counts = pd.Series(self.baseline_data["consecutive"]).value_counts().sort_index()
        max_consec = max(vrf_consec_counts.index.max(), baseline_consec_counts.index.max())
        x = range(max_consec + 1)
        vrf_data = [vrf_consec_counts.get(i, 0) for i in x]
        baseline_data = [baseline_consec_counts.get(i, 0) for i in x]
        width = 0.35
        plt.bar([i - width / 2 for i in x], vrf_data, width, label='VRF机制')
        plt.bar([i + width / 2 for i in x], baseline_data, width, label='传统随机（受操纵）')
        plt.title('恶意节点操纵场景下的连续入选分布')
        plt.xlabel('连续入选的恶意节点数量')
        plt.ylabel('出现次数')
        plt.xticks(x)
        plt.legend()
        plt.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_manipulated_consecutive{self.total_rounds}_{self.total_users}.svg', dpi=300, format="svg")
        # 注释掉 plt.show()
        plt.close()  # 关闭图形以释放内存

    def plot_box_comparison(self):
        plt.figure(figsize=(12, 6))
        data = [self.vrf_data["malicious_in"], self.baseline_data["malicious_in"]]
        # 兼容新旧版本的 Matplotlib
        try:
            plt.boxplot(data, tick_labels=['VRF机制', '传统随机（受操纵）'])
        except TypeError:
            # 对于旧版本 Matplotlib
            plt.boxplot(data, labels=['VRF机制', '传统随机（受操纵）'])
        plt.axhline(y=self.theoretical_malicious_per_round, color='g', linestyle='--',
                    label=f'理论值 ({self.theoretical_malicious_per_round})')
        plt.title('恶意节点操纵场景下的入选数量分布')
        plt.ylabel('恶意节点数量')
        plt.legend()
        plt.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        plt.savefig(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_manipulated_boxplot{self.total_rounds}_{self.total_users}.svg', dpi=300, format="svg")
        # 注释掉 plt.show()
        plt.close()  # 关闭图形以释放内存

    def generate_statistical_summary(self):
        """生成统计摘要（突出操纵场景的差异）"""
        # 处理可能为空的情况
        vrf_consecutive_nonzero_ratio = 0.0
        baseline_consecutive_nonzero_ratio = 0.0

        if len(self.vrf_data["consecutive"]) > 0:
            vrf_consecutive_nonzero_ratio = np.mean([1 if c > 0 else 0 for c in self.vrf_data["consecutive"]]) * 100

        if len(self.baseline_data["consecutive"]) > 0:
            baseline_consecutive_nonzero_ratio = np.mean(
                [1 if c > 0 else 0 for c in self.baseline_data["consecutive"]]) * 100

        summary = {
            '指标': [
                '平均恶意节点数量',
                '恶意节点数量标准差',
                '平均比例偏差',
                '最大连续入选恶意节点数',
                '连续入选次数>0的比例'
            ],
            'VRF机制（抗操纵）': [
                f'{np.mean(self.vrf_data["malicious_in"]):.2f}',
                f'{np.std(self.vrf_data["malicious_in"]):.2f}',
                f'{np.mean(self.vrf_data["ratio_deviation"]) * 100:.2f}%',
                f'{max(self.vrf_data["consecutive"])}',
                f'{vrf_consecutive_nonzero_ratio:.2f}%' if not np.isnan(vrf_consecutive_nonzero_ratio) else '0.00%'
            ],
            '传统随机（受操纵）': [
                f'{np.mean(self.baseline_data["malicious_in"]):.2f}',
                f'{np.std(self.baseline_data["malicious_in"]):.2f}',
                f'{np.mean(self.baseline_data["ratio_deviation"]) * 100:.2f}%',
                f'{max(self.baseline_data["consecutive"])}',
                f'{baseline_consecutive_nonzero_ratio:.2f}%' if not np.isnan(
                    baseline_consecutive_nonzero_ratio) else '0.00%'
            ]
        }
        df = pd.DataFrame(summary)
        print("恶意节点操纵场景下的统计摘要:")
        print(df.to_string(index=False))
        df.to_csv(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_manipulated_statistics_summary{self.total_rounds}_{self.total_users}.csv', index=False,
                  encoding='utf-8-sig')
        return df

    def save_data_to_csv(self):
        """保存原始数据到CSV文件"""
        # 保存VRF机制数据
        vrf_df = pd.DataFrame({
            'round': range(1, self.total_rounds + 1),
            'selected_malicious_count': self.vrf_data["malicious_in"],
            'ratio_deviation': self.vrf_data["ratio_deviation"],
            'consecutive_malicious': self.vrf_data["consecutive"]
        })
        vrf_df.to_csv(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_vrf_mechanism_data{self.total_rounds}_{self.total_users}.csv', index=False, encoding='utf-8-sig')

        # 保存传统随机机制数据
        baseline_df = pd.DataFrame({
            'round': range(1, self.total_rounds + 1),
            'selected_malicious_count': self.baseline_data["malicious_in"],
            'ratio_deviation': self.baseline_data["ratio_deviation"],
            'consecutive_malicious': self.baseline_data["consecutive"]
        })
        baseline_df.to_csv(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_baseline_mechanism_data{self.total_rounds}_{self.total_users}.csv', index=False,
                           encoding='utf-8-sig')

        # 保存选中客户端的详细信息
        vrf_selected_df = pd.DataFrame({
            f'round_{i + 1}': selected for i, selected in enumerate(self.vrf_data["selected"])
        }).T
        vrf_selected_df.to_csv(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_vrf_selected_clients{self.total_rounds}_{self.total_users}.csv', encoding='utf-8-sig')

        baseline_selected_df = pd.DataFrame({
            f'round_{i + 1}': selected for i, selected in enumerate(self.baseline_data["selected"])
        }).T
        baseline_selected_df.to_csv(f'./exp_data2/{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}_baseline_selected_clients{self.total_rounds}_{self.total_users}.csv',
                                    encoding='utf-8-sig')


# 运行操纵场景实验
if __name__ == "__main__":
    # 确保输出目录存在
    import os

    os.makedirs('./exp_data2', exist_ok=True)

    analyzer = MaliciousNodeAnalyzer(
        total_users=100,
        malicious_ratio=0.2,
        selection_frac=0.2,
        total_rounds=50,
        manipulation_strength=0.8  # 操纵强度：0.8表示恶意节点权重提升80%
    )

    print("运行恶意节点操纵场景实验...")
    analyzer.run_simulation()

    print("保存实验数据为CSV文件...")
    analyzer.save_data_to_csv()

    print("生成可视化结果...")
    analyzer.plot_malicious_count()
    analyzer.plot_ratio_deviation()
    analyzer.plot_consecutive_analysis()
    analyzer.plot_box_comparison()

    summary_df = analyzer.generate_statistical_summary()
    print("实验完成！结果已保存为PNG图片和CSV表格。")