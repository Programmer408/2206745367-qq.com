#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6
import copy
import time

import numpy as np
import torch
from cryptography.hazmat.primitives import padding
from torch.utils.data import DataLoader, Dataset
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from verification.AuxiliaryNode import bytes_to_float


def mark_malicious_clients(idxs_users, args):
    num_malicious = int(idxs_users * args.malicious_ratio)
    if num_malicious < 1 and args.malicious_ratio > 0:
        num_malicious = 1
    malicious_clients = set(np.random.choice(idxs_users, num_malicious, replace=False))
    return malicious_clients


def add_noise(weights, tamper_scale):
    print(f"[攻击警告] 正在执行梯度篡改,攻击强度{tamper_scale}")
    return {k: v + torch.randn_like(v) * tamper_scale
            for k, v in weights.items()}


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label


class LocalUpdate(object):
    def __init__(self, args, user_id, auxiliary_nodes, is_malicious, dataset=None, idxs=None):
        self.args = args
        self.is_malicious = is_malicious
        self.dataset = dataset

        # 根据攻击类型选择攻击策略
        if self.is_malicious:
            if args.attack_type == 'model_replacement':
                print(f"[模型替换攻击] 客户端{user_id}被标记为恶意客户端，准备执行模型替换攻击")
                self.attack_scale = args.attack_scale  # 攻击放大系数
                self.target_model = None  # 目标模型（用于模型替换）
            elif args.attack_type == 'label_attack':
                print("[标签置换攻击] 正在执行标签置乱攻击")
                self.dataset = self._poison_labels(self.dataset)

        self.idxs = idxs
        if isinstance(idxs, set):
            self.idxs = list(idxs)  # 将集合转换为列表

        self.ldr_train = self._create_data_loader()
        self.loss_func = torch.nn.CrossEntropyLoss()

        self.user_id = user_id
        self.auxiliary_nodes = auxiliary_nodes

    def _poison_labels(self, dataset):
        """标签置乱攻击核心函数"""
        poisoned_data = []
        for (img, label) in dataset:
            # 按比例篡改标签
            if torch.rand(1) < self.args.attack_ratio:
                if self.args.label_attack_type == 'random':
                    # 随机置换标签
                    new_label = torch.randint(0, self.args.num_classes, (1,)).item()
                elif self.args.label_attack_type == 'targeted':
                    # 定向攻击：将src_class的样本标记为tgt_class
                    new_label = self.args.tgt_class if label == self.args.src_class else label
                else:
                    new_label = label
            else:
                new_label = label
            poisoned_data.append((img, new_label))
        return poisoned_data

    def _create_target_model(self, global_model):
        """创建目标模型（用于模型替换攻击）"""
        print(f"[模型替换攻击] 客户端{self.user_id}正在创建目标模型")

        # 方法1：随机初始化（最简单的攻击）
        if self.args.replacement_method == 'random':
            target_model = copy.deepcopy(global_model)
            for param in target_model.parameters():
                param.data = torch.randn_like(param) * self.args.replacement_scale

        # 方法2：反向梯度攻击
        elif self.args.replacement_method == 'reverse':
            target_model = copy.deepcopy(global_model)
            for param in target_model.parameters():
                param.data = param.data * -self.args.replacement_scale

        # 方法3：缩放攻击
        elif self.args.replacement_method == 'scale':
            target_model = copy.deepcopy(global_model)
            for param in target_model.parameters():
                param.data = param.data * self.args.replacement_scale

        # 方法4：目标特定模型（如后门模型）
        elif self.args.replacement_method == 'targeted':
            target_model = copy.deepcopy(global_model)
            # 这里可以添加特定后门逻辑
            # 例如：使模型对特定输入产生特定输出

        return target_model

    def _poison_weights(self, trained_weights, global_weights):
        """对训练后的权重进行恶意篡改（模型替换攻击核心）"""
        print(f"[模型替换攻击] 客户端{self.user_id}正在执行模型替换，攻击强度: {self.args.attack_scale}")

        poisoned_weights = {}

        if self.args.replacement_strategy == 'direct_replacement':
            # 直接替换为攻击者指定的模型
            if self.target_model is None:
                self.target_model = self._create_target_model(global_weights)
            poisoned_weights = copy.deepcopy(self.target_model)

        elif self.args.replacement_strategy == 'amplified_update':
            # 放大更新量：Δw' = η * (w_malicious - w_global)
            for key in trained_weights.keys():
                # 计算正常的本地更新
                normal_update = trained_weights[key] - global_weights[key]
                # 放大更新
                amplified_update = normal_update * self.args.attack_scale
                # 应用放大后的更新
                poisoned_weights[key] = global_weights[key] + amplified_update

        elif self.args.replacement_strategy == 'scaled_replacement':
            # 缩放替换：w' = w_global + scale * (w_target - w_global)
            if self.target_model is None:
                self.target_model = self._create_target_model(global_weights)

            for key in trained_weights.keys():
                target_update = self.target_model[key] - global_weights[key]
                poisoned_weights[key] = global_weights[key] + target_update * self.args.attack_scale

        elif self.args.replacement_strategy == 'partial_replacement':
            # 部分参数替换（更隐蔽）
            if self.target_model is None:
                self.target_model = self._create_target_model(global_weights)

            for i, key in enumerate(trained_weights.keys()):
                if i % self.args.replacement_frequency == 0:  # 按频率替换
                    poisoned_weights[key] = self.target_model[key]
                else:
                    poisoned_weights[key] = trained_weights[key]

        elif self.args.replacement_strategy == 'gradient_ascent':
            # 梯度上升攻击（使模型性能下降）
            for key in trained_weights.keys():
                poisoned_weights[key] = trained_weights[key] + torch.randn_like(
                    trained_weights[key]) * self.args.attack_scale

        # 添加噪声以逃避检测
        if self.args.add_noise_to_evade:
            noise_scale = self.args.evasion_noise_scale
            for key in poisoned_weights.keys():
                poisoned_weights[key] += torch.randn_like(poisoned_weights[key]) * noise_scale

        return poisoned_weights

    def _create_data_loader(self):
        subset = torch.utils.data.Subset(self.dataset, self.idxs)
        return torch.utils.data.DataLoader(
            subset,
            batch_size=self.args.local_bs,
            shuffle=True,
            num_workers=0
        )

    def _decrypt_params(self):
        """解密来自所有辅助节点的参数"""
        K_list = []
        alpha_list = []

        for aux in self.auxiliary_nodes:
            try:
                # 确保使用正确的密钥键 (user_id, aux_id)
                key_tuple = (self.user_id, aux.node_id)
                encrypted_data = aux.get_encrypted_data(self.user_id)
                if not encrypted_data:
                    print(f"无加密数据：用户{self.user_id} 节点{aux.node_id}")
                    continue

                # 提取共享密钥
                shared_key = aux.shared_keys.get(key_tuple, b'')
                if not shared_key:
                    print(f"缺少共享密钥：用户{self.user_id} 节点{aux.node_id}")
                    continue

                # 处理密钥长度
                key = shared_key.ljust(16, b'\0')[:16]

                # 拆分IV和密文
                iv = encrypted_data[:16]
                ct = encrypted_data[16:]
                if len(ct) % 16 != 0:
                    print(f"异常密文长度：{len(ct)}字节")
                    continue

                # 解密流程
                cipher = Cipher(
                    algorithms.AES(key),
                    modes.CBC(iv)
                ).decryptor()

                decrypted_padded = cipher.update(ct) + cipher.finalize()

                # 移除填充（兼容空数据情况）
                unpadder = padding.PKCS7(128).unpadder()
                try:
                    pt = unpadder.update(decrypted_padded) + unpadder.finalize()
                except ValueError as e:
                    print(f"解填充失败：{str(e)}")
                    continue

                # 解析参数
                try:
                    params = pt.decode('utf-8').split(',')
                    if len(params) != 2:
                        raise ValueError("参数格式错误")

                    km, alpha = map(float, params)
                    K_list.append(km)
                    alpha_list.append(alpha)

                except (ValueError, UnicodeDecodeError) as e:
                    print(f"参数解析失败：{str(e)}")
                    continue

            except Exception as e:
                print(f"节点{aux.node_id}处理异常：{str(e)}")
                continue

        # 确保至少有一个有效结果
        if not K_list or not alpha_list:
            print("所有节点解密失败")
            return None, None

        return sum(K_list), sum(alpha_list)

    def train(self, net):
        # 保存初始参数（全局模型参数）
        global_params = copy.deepcopy(net.state_dict())

        # 如果是恶意客户端且执行模型替换攻击，可以跳过实际训练
        if self.is_malicious and self.args.attack_type == 'model_replacement' and self.args.skip_training:
            print(f"[模型替换攻击] 客户端{self.user_id}跳过实际训练，直接进行模型替换")
            # 直接使用全局参数作为"训练后"的参数
            trained_weights = copy.deepcopy(global_params)
        else:
            # 正常训练流程
            self.initial_params = copy.deepcopy(global_params)

            net.train()
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
            epoch_loss = []

            for _ in range(self.args.local_ep):
                batch_loss = []
                for images, labels in self.ldr_train:
                    images, labels = images.to(self.args.device), labels.to(self.args.device)
                    optimizer.zero_grad()
                    log_probs = net(images)
                    loss = torch.nn.functional.cross_entropy(log_probs, labels)
                    loss.backward()
                    optimizer.step()
                    batch_loss.append(loss.item())
                epoch_loss.append(sum(batch_loss) / len(batch_loss))

            trained_weights = net.state_dict()

        # 如果是恶意客户端且执行模型替换攻击，篡改权重
        if self.is_malicious and self.args.attack_type == 'model_replacement':
            print(f"[模型替换攻击] 客户端{self.user_id}正在实施模型替换攻击")
            trained_weights = self._poison_weights(trained_weights, global_params)

        # 计算MAC等验证信息
        start_time = time.time()

        # 计算参数变化量
        delta_params = {
            name: trained_weights[name] - self.initial_params[name]
            for name in trained_weights
        }
        flat_delta = torch.cat([delta.view(-1) for delta in delta_params.values()])
        client_grad_norm = torch.norm(flat_delta, p=2).item()

        # 计算Kn（共享密钥之和）
        Kn = sum(
            bytes_to_float(aux.shared_keys[(self.user_id, aux.node_id)])
            for aux in self.auxiliary_nodes
            if (self.user_id, aux.node_id) in aux.shared_keys
        )

        # 解密全局参数
        decrypt_result = self._decrypt_params()
        if not decrypt_result:
            print(f"用户{self.user_id}参数解密失败")
            return None, None, None, None

        global_K, global_alpha = decrypt_result

        # 计算MAC
        mac = Kn + global_alpha * client_grad_norm
        print(f"--------计算所用时间：{time.time() - start_time}")

        # 如果是恶意客户端，可以选择性伪造MAC
        if self.is_malicious and self.args.attack_type == 'model_replacement' and self.args.forge_mac:
            print(f"[模型替换攻击] 客户端{self.user_id}伪造MAC值")
            # 伪造一个合理的MAC值以逃避检测
            mac = Kn + global_alpha * (client_grad_norm * self.args.mac_forge_factor)

        avg_loss = 0.0
        if not (self.is_malicious and self.args.attack_type == 'model_replacement' and self.args.skip_training):
            avg_loss = sum(epoch_loss) / len(epoch_loss) if epoch_loss else 0.0

        return trained_weights, avg_loss, mac, client_grad_norm