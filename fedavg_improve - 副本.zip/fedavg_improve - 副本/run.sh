python ver_fed.py --dataset mnist --attack_ratio 0.1
python ver_fed.py --dataset mnist --attack_ratio 0.2
python ver_fed.py --dataset mnist --attack_ratio 0.3
python ver_fed.py --dataset mnist --attack_ratio 0.4
python ver_fed.py --dataset mnist --attack_ratio 0.5
python ver_fed.py --dataset mnist --attack_ratio 0.6
python ver_fed.py --dataset mnist --attack_ratio 0.7
python ver_fed.py --dataset mnist --attack_ratio 0.8
python ver_fed.py --dataset mnist --attack_ratio 0.9
python ver_fed.py --dataset mnist --attack_ratio 1.0
python ver_fed.py --dataset mnist --attack_ratio 1.0 --malicious_ratio 0.15
python ver_fed.py --dataset mnist --attack_ratio 1.0 --malicious_ratio 0.20

python ver_fed.py --dataset mnist --attack_ratio 1.0 --malicious_ratio 0.15
python ver_fed.py --dataset mnist --attack_ratio 1.0 --malicious_ratio 0.20
python ver_fed.py --dataset fmnist --attack_ratio 1.0 --malicious_ratio 0.15
python ver_fed.py --dataset fmnist --attack_ratio 1.0 --malicious_ratio 0.20
python ver_fed.py --dataset cifar --attack_ratio 1.0 --malicious_ratio 0.15
python ver_fed.py --dataset cifar --attack_ratio 1.0 --malicious_ratio 0.20

python ver_fed.py --dataset cifar --model cnn --attack_ratio 0 --malicious_ratio 0
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.1
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.2
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.3
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.4
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.5
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.6
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.7
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.8
python ver_fed.py --dataset cifar --model cnn --attack_ratio 0.9
python ver_fed.py --dataset cifar --model cnn --attack_ratio 1.0
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0 --malicious_ratio 0
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.1
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.2
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.3
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.4
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.5
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.6
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.7
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.8
python ver_fed.py --dataset cifar --model mlp --attack_ratio 0.9
python ver_fed.py --dataset cifar --model mlp --attack_ratio 1.0

#python ver_fed.py --dataset cifar --malicious_ratio 0 --iid True --model cnn --num_channels 1
python ver_fed.py --dataset cifar --malicious_ratio 0 --iid False --model cnn --num_channels 1
python ver_fed.py --dataset fmnist --malicious_ratio 0 --iid False --model cnn --num_channels 1
#python ver_fed.py --dataset cifar --malicious_ratio 0 --iid True --model mlp --num_channels 3


#python ver_fed.py --dataset cifar --malicious_ratio 0 --model mlp --num_channels 3
#python ver_fed.py --dataset fmnist --malicious_ratio 0 --model mlp --num_channels 3
#python ver_fed.py --dataset mnist --malicious_ratio 0 --model cnn --num_channels 1
#python ver_fed.py --dataset fmnist --malicious_ratio 0 --model cnn --num_channels 1
#python ver_fed.py --dataset cifar --malicious_ratio 0 --model cnn --num_channels 1
#
#python ver_fed.py --dataset fmnist --malicious_ratio 0.2 --model mlp --num_channels 3
#python ver_fed.py --dataset fmnist --malicious_ratio 0.15 --model mlp --num_channels 3
#
#python ver_fed.py --dataset fmnist --malicious_ratio 0.15  --model cnn --num_channels 1
#python ver_fed.py --dataset cifar --malicious_ratio 0.15 --model cnn --num_channels 1
#python ver_fed.py --dataset cifar --malicious_ratio 0.2 --model cnn --num_channels 1
#python ver_fed.py --dataset cifar --malicious_ratio 0.15 --model mlp --num_channels 3
#python ver_fed.py --dataset cifar --malicious_ratio 0.2 --model mlp --num_channels 3
#python ver_fed.py --dataset mnist --malicious_ratio 0.15 --model mlp --num_channels 3
python ver_fed.py --dataset mnist --malicious_ratio 0.2 --model mlp --num_channels 3

python ver_fed.py --tamper_scale 0.05 --verify True

python ver_fed.py --tamper_scale 0.1 --verify True

python ver_fed.py --tamper_scale 0.2 --verify True

python ver_fed.py --tamper_scale 0.1 --dataset fmnist
python ver_fed.py --tamper_scale 0.2 --dataset fmnist
python ver_fed.py --tamper_scale 0.05 --dataset cifar
python ver_fed.py --tamper_scale 0.1 --dataset cifar
python ver_fed.py --tamper_scale 0.2 --dataset cifar

python ver_fed.py  --attack_ratio 0.1
python ver_fed.py  --attack_ratio 0.2
python ver_fed.py  --attack_ratio 0.3
python ver_fed.py  --attack_ratio 0.4
python ver_fed.py  --attack_ratio 0.5
python ver_fed.py  --attack_ratio 0.6
python ver_fed.py  --attack_ratio 0.7
python ver_fed.py  --attack_ratio 0.8
python ver_fed.py  --attack_ratio 0.9
python ver_fed.py  --attack_ratio 1.0

python ver_fed.py --tamper_scale 0.05
python ver_fed.py --tamper_scale 0.1
python ver_fed.py --tamper_scale 0.2
python ver_fed.py --tamper_scale 0.05 --verify True
python ver_fed.py --tamper_scale 0.1 --verify True
python ver_fed.py --tamper_scale 0.2 --verify True

