import torch
import torch.nn as nn
import torch.nn.functional as F

class resnet18_improve(nn.Module):
    # resnet18中的基本残差块
    def __init__(self, input_channels, output_channels, first_conv=False, first_strides=2, strides=1): 
        '''
        first_conv: 是否是残差块的第一部分（需要下采样）
        first_strides: first_conv=True时的卷积步长
        strides: first_conv=False时的卷积步长
        '''
        super().__init__()
        # conv1为第一个卷积，conv3为shortcut_connection的1x1卷积，conv2为第二个卷积
        if first_conv:
            self.conv1 = nn.Conv2d(input_channels, output_channels, kernel_size=3, padding=1, stride=first_strides)
            self.conv3 = nn.Conv2d(input_channels, output_channels, kernel_size=1, padding=0, stride=first_strides)
        else:
            self.conv1 = nn.Conv2d(output_channels, output_channels, kernel_size=3, padding=1, stride=strides)
            self.conv3 = None
        self.conv2 = nn.Conv2d(output_channels, output_channels, kernel_size=3, padding=1, stride=strides)
        self.bn1 = nn.BatchNorm2d(output_channels)
        self.bn2 = nn.BatchNorm2d(output_channels)
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.bn2(self.conv2(y))
        if self.conv3:
            y += self.conv3(x)
        else:
            y += x
        return self.relu(y)

def resnet_zone(input_channels, out_channels, number=2, first_resnet=False, dropout=[0.4, 0.4]):
    # 构建一个残差区域
    res = []
    if first_resnet:
        res.append(resnet18_improve(input_channels, out_channels, False))
    else:
        res.append(resnet18_improve(input_channels, out_channels, True))
    res.append(nn.Dropout(dropout[0]))
    
    for i in range(1, number-1):
        res.append(resnet18_improve(out_channels, out_channels, False))
        res.append(nn.Dropout(dropout[1]))
    
    res.append(resnet18_improve(out_channels, out_channels, False))
    return res

class CIFAR10_ResNet18(nn.Module):
    def __init__(self, num_classes=10):
        super(CIFAR10_ResNet18, self).__init__()
        
        # 第一层：相比于标准ResNet，使用更小的卷积核和步长以适应CIFAR-10的32x32尺寸
        self.b1 = nn.Sequential(
            nn.Conv2d(3, 64, 3, 1, 1), 
            nn.BatchNorm2d(64), 
            nn.ReLU(inplace=True)
        )
        
        # 残差区域
        self.b2 = nn.Sequential(*resnet_zone(64, 64, 2, True, dropout=[0.3, 0.4]))
        self.b3 = nn.Sequential(*resnet_zone(64, 128))
        self.b4 = nn.Sequential(*resnet_zone(128, 256))
        self.b5 = nn.Sequential(*resnet_zone(256, 512, dropout=[0.5, 0.5]))
        
        # 分类层
        self.b6 = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)), 
            nn.Dropout(0.3), 
            nn.Flatten(),  
            nn.Linear(512, num_classes, bias=True)
        )
        
    def forward(self, x):
        x = self.b1(x)
        x = self.b2(x)
        x = self.b3(x)
        x = self.b4(x)
        x = self.b5(x)
        x = self.b6(x)
        return x

# 使用示例
if __name__ == "__main__":
    # 创建模型实例
    model = CIFAR10_ResNet18(num_classes=10)
    
    # 测试模型
    x = torch.randn(2, 3, 32, 32)  # 批量大小2，3通道，32x32图像
    output = model(x)
    print(f"输出形状: {output.shape}")  # 应该是 torch.Size([2, 10])
    print(f"模型参数量: {sum(p.numel() for p in model.parameters())}")