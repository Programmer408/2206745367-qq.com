import torch

# 打印基本信息
print(f"PyTorch 版本: {torch.__version__}")
print(f"CUDA 可用: {torch.cuda.is_available()}")
print(f"CUDA 版本: {torch.version.cuda}")

# 如果有可用 GPU
if torch.cuda.is_available():
    device = torch.device("cuda")
    print(f"GPU 设备: {torch.cuda.get_device_name(0)}")

    # 获取计算能力
    capability = torch.cuda.get_device_capability(0)
    print(f"计算能力: sm_{capability[0]}{capability[1]}")

    # 检查支持的架构
    print(f"支持的架构: {torch.cuda.get_arch_list()}")

    # 运行简单的 GPU 计算测试
    a = torch.randn(1000, 1000).to(device)
    b = torch.randn(1000, 1000).to(device)
    c = torch.matmul(a, b)
    print("GPU 计算测试完成!")
else:
    print("没有检测到可用的 GPU")