from abc import abstractmethod


class Handler():
    def __init__(self):
        pass

    @abstractmethod
    def generate_keys(self):
        """生成密钥对 """

    @abstractmethod
    def generate_randomness(self, secret_key, input_bytes):
        """生成随机性 """

    @abstractmethod
    def verify_randomness(self, input_bytes, public_key, randomness, proof):
        """验证随机性 """
