#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6
# tensorboard --logdir=./logs
# tensorboard --logdir=./logs_server
import time
import random
import matplotlib

from performance_tracker import PerformanceTracker, calculate_communication_overhead
from utils.DataAnalsys import visualize_detection_metrics
from utils.vrf import VRFServer, VRFClient, select_clients_vrf_enhanced
from torch.utils.tensorboard import SummaryWriter
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import copy
from torchvision import datasets, transforms
import torch
from utils.sampling import mnist_iid, mnist_noniid, cifar_iid
from utils.options import args_parser
from models.Update import LocalUpdate, mark_malicious_clients, add_noise
from models.Nets import MLP, CNNMnist, CNNCifar, CNNFashionMnist, ResNet18, CIFAR10_ResNet18
from models.Fed import FedAvg
from models.test import test_img
from verification.AuxiliaryNode import AuxiliaryNode
from verification.AuxiliaryNode import generate_shared_keys
from verification.AuxiliaryNode import bytes_to_float


if __name__ == '__main__':

    # parse args
    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')
    #  writer = SummaryWriter(log_dir=f'./logs/{args.dataset}_{args.model}_users{args.num_users}_C{args.frac}_iid{args.iid}_epochs{args.epochs}_poison{args.malicious_ratio * args.num_users}_{args.label_attack_type}_{args.attack_ratio}')
    writer = SummaryWriter(
         log_dir=f'./logs/{args.dataset}_{args.model}_users{args.num_users}_C{args.frac}_iid{args.iid}_epochs{args.epochs}_Net18_improve')
    # writer = SummaryWriter(
    #     log_dir=f'./logs_server/{args.dataset}_{args.model}_users{args.num_users}_C{args.frac}_iid{args.iid}_epochs{args.epochs}_tamper_scale{args.tamper_scale}_{args.verify}')

    # 初始化性能跟踪器
    experiment_name = f"{args.dataset}_{args.model}_users{args.num_users}_C{args.frac}_iid{args.iid}_epochs{args.epochs}"
    perf_tracker = PerformanceTracker(experiment_name)

    # 添加通信统计变量
    comm_stats = {
        'total_upload': 0.0,  # 总上传量（MB）
        'total_download': 0.0,  # 总下载量（MB）
        'per_round': []  # 每轮通信量记录
    }

    # load dataset and split users
    if args.dataset == 'mnist':
        trans_mnist = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        dataset_train = datasets.MNIST('./data/mnist/', train=True, download=True, transform=trans_mnist)
        dataset_test = datasets.MNIST('./data/mnist/', train=False, download=True, transform=trans_mnist)
        # sample users
        if args.iid:
            dict_users = mnist_iid(dataset_train, args.num_users)
        else:
            dict_users = mnist_noniid(dataset_train, args.num_users)
    elif args.dataset == 'fmnist':
        # 数据预处理保持与MNIST一致
        trans_fmnist = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
        dataset_train = datasets.FashionMNIST('./data/mnist/', train=True, download=True, transform=trans_fmnist)
        dataset_test = datasets.FashionMNIST('./data/mnist/', train=False, download=True, transform=trans_fmnist)
        # sample users
        if args.iid:
            dict_users = mnist_iid(dataset_train, args.num_users)
        else:
            dict_users = mnist_noniid(dataset_train, args.num_users)
    elif args.dataset == 'cifar':
        trans_cifar = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        dataset_train = datasets.CIFAR10('./data/cifar', train=True, download=True, transform=trans_cifar)
        dataset_test = datasets.CIFAR10('./data/cifar', train=False, download=True, transform=trans_cifar)
        if args.iid:
            dict_users = cifar_iid(dataset_train, args.num_users)
        else:
            exit('Error: only consider IID setting in CIFAR10')
    elif args.dataset == 'cifar100':
        # trans_cifar = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
        trans_cifar = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5071, 0.4867, 0.4408), (0.2675, 0.2565, 0.2761))])
        dataset_train = datasets.CIFAR100('./data/cifar100', train=True, download=True, transform=trans_cifar)
        dataset_test = datasets.CIFAR100('./data/cifar100', train=False, download=True, transform=trans_cifar)
        if args.iid:
            dict_users = cifar_iid(dataset_train, args.num_users)
        else:
            exit('Error: only consider IID setting in CIFAR100')
    else:
        exit('Error: unrecognized dataset')
    img_size = dataset_train[0][0].shape

    # build model
    if args.model == 'cnn' and args.dataset == 'cifar':
        net_glob = CIFAR10_ResNet18(args=args).to(args.device)
    elif args.model == 'cnn' and args.dataset == 'cifar100':
        net_glob = ResNet18(args=args).to(args.device)
    elif args.model == 'cnn' and args.dataset == 'mnist':
        net_glob = CNNMnist(args=args).to(args.device)
    elif args.model == 'cnn' and args.dataset == 'fmnist':
        net_glob = CNNFashionMnist(args=args).to(args.device)
    elif args.model == 'mlp':
        len_in = 1
        for x in img_size:
            len_in *= x
        net_glob = MLP(dim_in=len_in, dim_hidden=200, dim_out=args.num_classes).to(args.device)
    else:
        exit('Error: unrecognized model')
    print(net_glob)
    print(f"当前用户数量:{args.num_users}")
    print(f"当前辅助节点数量:{args.num_auxiliaries}")
    print(f"当前每轮参与客户端数量:{args.frac * args.num_users}")
    print(f"当前恶意客户端数量:{args.malicious_ratio * args.num_users}")

    net_glob.train()

    # copy weights
    w_glob = net_glob.state_dict()

    # training
    loss_train = []
    cv_loss, cv_acc = [], []
    val_loss_pre, counter = 0, 0
    net_best = None
    best_loss = None
    val_acc_list, net_list = [], []

    if args.all_clients: 
        print("Aggregation over all clients")
        w_locals = [w_glob for i in range(args.num_users)]

    num_aux_nodes = args.num_auxiliaries

    start = time.time()
    shared_keys_global = generate_shared_keys(args.num_users, args.num_auxiliaries)
    print(f"生成密钥时间用时{time.time() - start:.10f}s")

    # 初始化辅助节点时传入共享密钥
    start = time.time()
    auxiliary_nodes = [
        AuxiliaryNode(
            node_id=aux_id,
            num_users=args.num_users,
            shared_keys={
                (user_id, aux_id): shared_keys_global[(user_id, aux_id)]  # 保持元组键
                for user_id in range(args.num_users)
            }
        )
        for aux_id in range(args.num_auxiliaries)
    ]
    print(f"密钥共享时间用时{time.time() - start:.10f}s")

    # 存储全局验证参数
    global_alpha_history = []
    global_K_history = []
    mac_history = []

    # print("成功执行到循环训练之前")

    vrf_server = VRFServer()
    clients = [VRFClient(f"client_{i}") for i in range(args.num_users)]
    for c in clients:
        vrf_server.register_client(c)

    malicious_set = mark_malicious_clients(args.num_users, args)
    print(f"恶意用户集合: {malicious_set}")

    tamper_detection_stats = {
        "total_tampered": 0,  # 实际篡改次数
        "detected_tampered": 0,  # 成功检测到的篡改次数
        "undetected_tampered": 0,  # 未检测到的篡改次数
        "normal_rounds": 0,  # 正常轮次总数
        "false_positives": 0,  # 正常梯度被误判为篡改的次数
        "verification_diffs": [],  # 存储每轮的验证差值
        "tampered_rounds": []  # 记录篡改发生的轮次
    }

    for iter in range(args.epochs):

        # 记录每轮开始时间
        round_start_time = time.time()

        # 开始内存监控
        perf_tracker.start_round_monitoring()

        start = time.time()
        # 阶段一：随机选择用户
        selected_users = select_clients_vrf_enhanced(vrf_server, clients, iter, args.frac)
        print(f"选择客户时间用时{time.time()-start:.2f}s")

        # 内存采样
        perf_tracker._sample_memory()

        # 阶段二：辅助节点生成新密钥（关键修改）
        for aux in auxiliary_nodes:
            aux.generate_keys(selected_users)  # 传入当前选中用户

        # 阶段三：计算全局参数
        global_K = sum(aux.Km for aux in auxiliary_nodes)
        global_alpha = sum(aux.alpha_m for aux in auxiliary_nodes)

        sum_Kn = sum(
            sum(
                bytes_to_float(aux.shared_keys[uid, aux.node_id])  # 将bytes转换为浮点数
                for aux in auxiliary_nodes
            )
            for uid in selected_users
        )

        sum_Km = sum(aux.Km for aux in auxiliary_nodes)

        assert abs(sum_Kn - sum_Km) < 1e-6, f"Kn总和 {sum_Kn:.6f} ≠ Km总和 {sum_Km:.6f}"

        # 内存采样
        perf_tracker._sample_memory()

        # --- 阶段四：联邦训练过程 ---
        macs = []
        w_locals = []
        loss_locals = []
        agg_grad = None  # 聚合梯度
        client_grad_norms = {}  # 存储各客户端梯度范数

        # print(f"Global K: {global_K}, Global alpha: {global_alpha}")  # 确认求和正确

        initial_global_weights = {key: value.detach().clone() for key, value in net_glob.state_dict().items()}
        initial_w = {key: value.detach().clone() for key, value in initial_global_weights.items()}

        # 记录训练时间
        training_start_time = time.time()
        for user_id in selected_users:

            is_malicious = user_id in malicious_set

            local = LocalUpdate(args=args,
                                dataset=dataset_train,
                                idxs=dict_users[user_id],
                                user_id=user_id,
                                is_malicious=is_malicious,
                                auxiliary_nodes=auxiliary_nodes)

            w, loss, mac, grad_norm = local.train(net=copy.deepcopy(net_glob).to(args.device))

            client_grad_norms[user_id] = grad_norm

            macs.append(mac)

            if args.all_clients:
                w_locals[user_id] = copy.deepcopy(w)
            else:
                w_locals.append(copy.deepcopy(w))
            loss_locals.append(copy.deepcopy(loss))

        total_samples = sum(len(dict_users[u]) for u in selected_users)
        training_time = time.time() - training_start_time

        # 内存采样
        perf_tracker._sample_memory()

        # --- 验证与全局聚合 ---
        # update global weights
        w_glob = FedAvg(w_locals)

        flag = False

        if args.tamper:
            if random.random() < args.random_tamper_prob:

                flag = True

                tamper_detection_stats["total_tampered"] += 1
                tamper_detection_stats["tampered_rounds"].append(iter)

                # 记录原始权重用于后续验证
                original_w_glob = copy.deepcopy(w_glob)

                # 执行梯度篡改（模拟攻击）
                w_glob = add_noise(w_glob, args.tamper_scale)

                # 应用篡改后的参数到全局模型
                net_glob.load_state_dict(w_glob)  # 关键修复：必须加载被篡改的权重


        tampered_mac = 0.0
        for user_id in selected_users:
            local = LocalUpdate(
                args=args,
                dataset=dataset_train,
                idxs=dict_users[user_id],
                user_id=user_id,
                is_malicious=False,
                auxiliary_nodes=auxiliary_nodes
            )

            # 计算篡改后的MAC
            _, _, mac, _ = local.train(net=copy.deepcopy(net_glob).to(args.device))
            tampered_mac += mac

        X = sum(client_grad_norms.values())

        aggregated_mac = sum(macs)

        # print(f'-------原始MAC={aggregated_mac}')
        # print(f'-------篡改后的MAC={tampered_mac}')
        # print(f'差值={aggregated_mac-tampered_mac}')

        verification_start_time = time.time()
        verification_result = tampered_mac - (global_K + global_alpha * X)
        tamper_detection_stats["verification_diffs"].append(verification_result)  # 添加这一行

        if args.verify:
            if abs(verification_result) < 3:
                print(f'Epoch {iter}: Verification Diff = {verification_result:.6f}')
                print("————————验证成功！聚合梯度未被修改————————")

                # 如果是篡改轮次但验证成功，说明漏检
                if flag:
                    tamper_detection_stats["undetected_tampered"] += 1

                # copy weight to net_glob
                net_glob.load_state_dict(w_glob)
            else:
                # 如果是正常轮次但验证失败，说明误判
                if not flag:

                    tamper_detection_stats["false_positives"] += 1
                else:
                    tamper_detection_stats["detected_tampered"] += 1
                print(f'Epoch {iter}: Verification Diff = {verification_result:.6f}')
                print("————————验证失败！聚合梯度已被修改,不进行参数更新————————")
                net_glob.load_state_dict(initial_global_weights)  # 恢复初始参数
                continue
        else:
            net_glob.load_state_dict(w_glob)

        verification_time = time.time() - verification_start_time

        # 记录正常轮次
        if not args.tamper:
            tamper_detection_stats["normal_rounds"] += 1

        print(f"验证阶段时间用时{time.time() - start:.2f}s")

        # print loss
        loss_avg = sum(loss_locals) / len(loss_locals)
        writer.add_scalar('Train/Loss', loss_avg, iter)
        print('Round {:3d}, Average loss {:.3f}'.format(iter, loss_avg))
        loss_train.append(loss_avg)

        # writer.add_scalar('Comm/VRF/Total_Upload', comm_stats['total_upload'], iter)
        # writer.add_scalar('Comm/VRF/Total_Download', comm_stats['total_download'], iter)

        net_glob.eval()
        acc_train, _ = test_img(net_glob, dataset_train, args)
        acc_test, _ = test_img(net_glob, dataset_test, args)

        writer.add_scalar('Final/Train_Accuracy', acc_train, iter)
        writer.add_scalar('Final/Test_Accuracy', acc_test, iter)

        # 记录每轮性能指标
        round_total_time = time.time() - round_start_time
        current_metrics = perf_tracker.get_current_metrics()

        communication_overhead = calculate_communication_overhead(
            selected_users, auxiliary_nodes, w_locals, w_glob
        )

        metrics_data = {
            'total_time': round_total_time,
            'training_time': training_time,
            'verification_time': verification_time,
            'memory_usage': current_metrics['memory_usage'],
            'communication_overhead': communication_overhead,
            'accuracy': acc_test,
            'loss': loss_avg
        }

        perf_tracker.record_round_metrics(iter, metrics_data)

    writer.close()
