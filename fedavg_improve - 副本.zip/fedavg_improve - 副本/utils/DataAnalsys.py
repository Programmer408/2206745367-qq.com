# 在文件开头添加所需的导入（如果还没有的话）
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from utils.options import args_parser

args = args_parser()

def visualize_detection_metrics(detection_rate, miss_rate, false_positive_rate, avg_diff,
                                verification_diffs=None, save_path='./save'):
    """
    可视化篡改检测指标

    参数:
    - detection_rate: 检测率
    - miss_rate: 漏检率
    - false_positive_rate: 误判率
    - avg_diff: 平均验证差值
    - verification_diffs: 所有验证差值列表（可选，用于生成详细图表）
    - save_path: 保存路径
    """
    import os
    os.makedirs(save_path, exist_ok=True)

    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
    plt.rcParams["axes.unicode_minus"] = False

    # 1. 绘制检测率相关指标柱状图
    plt.figure(figsize=(10, 6))
    metrics = ['检测率', '漏检率', '误判率']
    values = [detection_rate, miss_rate, false_positive_rate]
    colors = ['green', 'red', 'orange']

    bars = plt.bar(metrics, values, color=colors)
    plt.ylabel('比率')
    plt.title('篡改检测性能指标')
    plt.ylim(0, 1)

    # 在柱状图上显示数值
    for bar, value in zip(bars, values):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                 f'{value * 100:.2f}%', ha='center', va='bottom')

    plt.tight_layout()
    plt.savefig(f'./save/detection_metrics{args.tamper_scale}.png', dpi=300, bbox_inches='tight')
    plt.close()

    # 2. 绘制验证差值随轮次变化的折线图（如果有详细数据）
    if verification_diffs:
        plt.figure(figsize=(12, 6))
        rounds = range(len(verification_diffs))
        plt.plot(rounds, verification_diffs, 'b-', marker='o', markersize=3)
        plt.axhline(y=0, color='r', linestyle='--', alpha=0.7)
        plt.axhline(y=avg_diff, color='g', linestyle='-', alpha=0.7,
                    label=f'平均差值: {avg_diff:.6f}')
        plt.xlabel('训练轮次')
        plt.ylabel('验证差值')
        plt.title('验证差值随训练轮次的变化')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'./save/verification_diff_over_time{args.tamper_scale}.png', dpi=300, bbox_inches='tight')
        plt.close()

    # 3. 绘制验证差值的分布直方图（如果有详细数据）
    if verification_diffs:
        plt.figure(figsize=(10, 6))
        plt.hist(verification_diffs, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
        plt.axvline(x=avg_diff, color='red', linestyle='--', linewidth=2,
                    label=f'平均差值: {avg_diff:.6f}')
        plt.xlabel('验证差值')
        plt.ylabel('频次')
        plt.title('验证差值分布直方图')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(f'./save/verification_diff_distribution{args.tamper_scale}.png', dpi=300, bbox_inches='tight')
        plt.close()

    # 4. 绘制综合性能雷达图
    plt.figure(figsize=(8, 8))
    angles = np.linspace(0, 2 * np.pi, 3, endpoint=False).tolist()
    metrics_radar = ['检测率', '1-漏检率', '1-误判率']
    values_radar = [detection_rate, 1 - miss_rate, 1 - false_positive_rate]
    angles += angles[:1]
    values_radar += values_radar[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(projection='polar'))
    ax.plot(angles, values_radar, 'o-', linewidth=2, label='检测性能')
    ax.fill(angles, values_radar, alpha=0.25)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics_radar)
    ax.set_ylim(0, 1)
    ax.set_title('篡改检测综合性能雷达图', size=16, pad=20)
    plt.tight_layout()
    plt.savefig(f'./save/radar_chart{args.tamper_scale}.png', dpi=300, bbox_inches='tight')
    plt.close()

    print(f"可视化图表已保存到 {save_path} 目录")


# 如果还需要保存统计数据到CSV，可以添加这个函数
def save_detection_stats_to_csv(detection_rate, miss_rate, false_positive_rate, avg_diff,
                                total_tampered, detected_tampered, undetected_tampered,
                                normal_rounds, false_positives, save_path='./save'):
    """
    保存检测统计数据到CSV文件
    """
    import os
    os.makedirs(save_path, exist_ok=True)

    stats_df = pd.DataFrame({
        '指标': ['总篡改轮次', '成功检测次数', '未检测到次数', '正常轮次总数', '误判次数',
               '检测率(%)', '漏检率(%)', '误判率(%)', '平均验证差值'],
        '数值': [total_tampered,
               detected_tampered,
               undetected_tampered,
               normal_rounds,
               false_positives,
               detection_rate * 100,
               miss_rate * 100,
               false_positive_rate * 100,
               avg_diff]
    })

    stats_df.to_csv(f'./save/detection_statistics{args.tamper_scale}.csv', index=False, encoding='utf-8-sig')
    print(f"统计结果已保存到 {save_path}/detection_statistics.csv")
