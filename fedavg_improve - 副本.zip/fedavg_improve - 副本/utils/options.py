#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Python version: 3.6

import argparse


def args_parser():
    parser = argparse.ArgumentParser()
    # federated arguments
    parser.add_argument('--epochs', type=int, default=1, help="rounds of training")
    parser.add_argument('--num_users', type=int, default=100, help="number of users: K")
    parser.add_argument('--frac', type=float, default=0.1, help="the fraction of clients: C")
    parser.add_argument('--local_ep', type=int, default=5, help="the number of local epochs: E")
    parser.add_argument('--local_bs', type=int, default=10, help="local batch size: B")
    parser.add_argument('--bs', type=int, default=128, help="test batch size")
    parser.add_argument('--lr', type=float, default=0.01, help="learning rate")
    parser.add_argument('--momentum', type=float, default=0.5, help="SGD momentum (default: 0.5)")
    parser.add_argument('--split', type=str, default='user', help="train-test split type, user or sample")
    parser.add_argument('--num_auxiliaries', type=int, default=5, help=" the number of auxiliary nodes")
    parser.add_argument('--log_comm', action='store_true',
                        help='启用通信量统计')

    # 恶意客户端
    parser.add_argument('--malicious_ratio', type=float, default=0.1, help='恶意客户端比例 (default: 0.1)')
    # parser.add_argument('--attack_type', type=str, default='random', choices=['random', 'invert', 'noise'],
    #                     help='攻击类型: random|invert|noise')

    # 恶意服务器
    parser.add_argument('--tamper', action='store_true', default=False, help='启用服务器梯度篡改攻击')
    parser.add_argument('--tamper_scale', type=float, default=0.05,
                        help='梯度篡改强度系数（默认0.1）')
    parser.add_argument('--random_tamper_prob', type=float, default=0.5,
                        help='攻击概率')
    parser.add_argument('--verify', type=bool, default=True,
                        help='梯度验证')

    # 标签置乱攻击
    # parser.add_argument('--label_attack', action='store_true', default=True, help='启用标签置乱攻击')
    parser.add_argument('--attack_ratio', type=float, default=1.0,
                        help='被篡改标签的比例（默认0.3）')
    parser.add_argument('--label_attack_type', type=str, default='random',
                        choices=['random', 'targeted'],
                        help='攻击类型：random（随机置换）或 targeted（定向攻击）')
    parser.add_argument('--src_class', type=int, default=0,
                        help='定向攻击的源类别（仅targeted模式有效）')
    parser.add_argument('--tgt_class', type=int, default=1,
                        help='定向攻击的目标类别（仅targeted模式有效）')

    # 模型替换攻击
    # 在您的参数配置中添加
    parser.attack_type = 'model_replacement'  # 攻击类型：'model_replacement', 'label_attack', 'none'
    parser.attack_scale = 10.0  # 模型替换攻击的放大系数
    parser.replacement_strategy = 'amplified_update'  # 替换策略
    parser.replacement_method = 'scale'  # 目标模型创建方法
    parser.replacement_scale = 5.0  # 模型替换的缩放因子
    parser.replacement_frequency = 3  # 部分替换的频率
    parser.skip_training = True  # 恶意客户端是否跳过实际训练
    parser.forge_mac = False  # 是否伪造MAC值
    parser.add_noise_to_evade = True  # 是否添加噪声以逃避检测
    parser.evasion_noise_scale = 0.01  # 逃避检测的噪声强度
    parser.mac_forge_factor = 1.0  # MAC伪造因子

    # model arguments
    parser.add_argument('--model', type=str, default='cnn', help='model name')
    parser.add_argument('--kernel_num', type=int, default=9, help='number of each kind of kernel')
    parser.add_argument('--kernel_sizes', type=str, default='3,4,5',
                        help='comma-separated kernel size to use for convolution')
    parser.add_argument('--norm', type=str, default='batch_norm', help="batch_norm, layer_norm, or None")
    parser.add_argument('--num_filters', type=int, default=32, help="number of filters for conv nets")
    parser.add_argument('--max_pool', type=str, default='True',
                        help="Whether use max pooling rather than strided convolutions")

    # other arguments
    parser.add_argument('--dataset', type=str, default='cifar', help="name of dataset")
    parser.add_argument('--iid', action='store_true', default=True, help='whether i.i.d or not')
    parser.add_argument('--num_classes', type=int, default=10, help="number of classes")
    parser.add_argument('--num_channels', type=int, default=1, help="number of channels of imges")
    parser.add_argument('--gpu', type=int, default=0, help="GPU ID, -1 for CPU")
    parser.add_argument('--stopping_rounds', type=int, default=10, help='rounds of early stopping')
    parser.add_argument('--verbose', action='store_true', help='verbose print')
    parser.add_argument('--seed', type=int, default=1, help='random seed (default: 1)')
    parser.add_argument('--all_clients', action='store_true', help='aggregation over all clients')
    args = parser.parse_args()
    return args
