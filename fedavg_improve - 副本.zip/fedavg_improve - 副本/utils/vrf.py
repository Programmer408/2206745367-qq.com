import json
import logging
import os
import secrets
import time
from concurrent.futures import as_completed
from concurrent.futures import ThreadPoolExecutor

from utils.TrafficCounter import TrafficCounter
from verifiable_random_function import ecvrf_edwards25519_sha512_elligator2 as vrf_lib
import hashlib
import heapq
import base64


class VRFClient:
    def __init__(self, client_id):
        self.id = client_id
        self.sk = self._generate_sk()  # 私钥本地保存
        self.pk = vrf_lib.get_public_key(self.sk)  # 公钥需注册到服务器

    def _generate_sk(self) -> bytes:
        """安全生成32字节私钥"""
        return secrets.token_bytes(32)

    def generate_vrf(self, seed: bytes) -> (bytes, bytes):
        """生成VRF随机数及证明"""
        status, proof = vrf_lib.ecvrf_prove(self.sk, seed)
        if status != "VALID":
            raise RuntimeError("VRF生成失败")
        status, randomness = vrf_lib.ecvrf_proof_to_hash(proof)
        return randomness, proof


class VRFServer:
    def __init__(self):
        self.clients = {}  # {client_id: public_key}

    def register_client(self, client: VRFClient):
        """注册客户端公钥"""
        self.clients[client.id] = client.pk

    def verify_vrf(self, client_id: str, seed: bytes, randomness: bytes, proof: bytes) -> bool:
        """验证VRF有效性"""
        if client_id not in self.clients:
            return False
        pk = self.clients[client_id]
        status, _ = vrf_lib.ecvrf_verify(pk, proof, seed)
        return status == "VALID"

    def verify_batch(self, submissions):
        """优化批量验证流程"""
        valid_subs = []
        with ThreadPoolExecutor(max_workers=min(32, os.cpu_count() * 4)) as executor:
            futures = []
            for sub in submissions:
                futures.append(executor.submit(
                    self.verify_vrf,
                    sub['client_id'],
                    base64.b64decode(sub['seed']),
                    base64.b64decode(sub['randomness']),
                    base64.b64decode(sub['proof'])
                ))

            for sub, future in zip(submissions, futures):
                if future.result():
                    valid_subs.append(sub)
        return valid_subs

    # def select_top_k(self, submissions: list, k: int) -> list:
    #     """高效选择Top-K客户端"""
    #     # 提取随机数并转换为整数
    #     # 转换为 (随机数整数, client_id) 列表
    #     ranked = []
    #     for sub in submissions:
    #         randomness_bytes = base64.b64decode(sub['randomness'])
    #         rand_int = int.from_bytes(randomness_bytes[:16], 'big')
    #         ranked.append((rand_int, sub['client_id']))
    #     # 直接获取Top-K
    #     top_k = heapq.nlargest(k, ranked, key=lambda x: x[0])
    #     return [item[1] for item in top_k]
    def select_top_k(self, submissions: list, k: int) -> list:
        """使用堆选择Top-K，避免完全排序"""
        heap = []
        for sub in submissions:
            randomness_bytes = base64.b64decode(sub['randomness'])
            # 仅使用16字节计算整数（足够保证唯一性）
            rand_int = int.from_bytes(randomness_bytes[:16], 'big')

            # 使用最小堆维护Top-K
            if len(heap) < k:
                heapq.heappush(heap, (rand_int, sub['client_id']))
            else:
                # 如果当前值大于堆中最小值则替换
                if rand_int > heap[0][0]:
                    heapq.heapreplace(heap, (rand_int, sub['client_id']))

        # 提取结果（堆中已是Top-K）
        return [client_id for _, client_id in heap]


def select_clients_vrf_enhanced(vrf_server, clients, round_idx, frac):
    """基于VRF的公平选择流程"""
    upload_counter = TrafficCounter()
    download_counter = TrafficCounter()

    # 生成不可预测种子（示例使用混合种子）
    seed = hashlib.sha256(f"{round_idx}|{secrets.token_bytes(16)}".encode()).digest()

    # 种子下发流量（优化：仅计算一次）
    seed_size = len(seed) * len(clients)
    download_counter.total_bytes += seed_size

    # # 统计种子下发流量（假设每个客户端独立接收）
    # for _ in clients:
    #     download_counter.add_traffic(seed)

    # 收集客户端提交
    # submissions = []
    # for client in clients:
    #     randomness, proof = client.generate_vrf(seed)
    #     submission_data = {
    #         "client_id": client.id,
    #         "randomness": base64.b64encode(randomness).decode('utf-8'),  # bytes转base64字符串
    #         "proof": base64.b64encode(proof).decode('utf-8'),
    #         "seed": base64.b64encode(seed).decode('utf-8')
    #     }
    #     submission_bytes = json.dumps(submission_data).encode()
    #     upload_counter.add_traffic(submission_bytes)
    #     submissions.append(submission_data)
    #
    # 验证并筛选有效提交
    # valid_subs = []
    # for sub in submissions:
    #     # 将base64字符串转回bytes
    #     randomness_bytes = base64.b64decode(sub['randomness'])
    #     proof_bytes = base64.b64decode(sub['proof'])
    #     seed_bytes = base64.b64decode(sub['seed'])
    #
    #     if vrf_server.verify_vrf(sub['client_id'], seed_bytes, randomness_bytes, proof_bytes):
    #         valid_subs.append(sub)

    # 并行生成VRF
    with ThreadPoolExecutor() as executor:
        futures = {executor.submit(client.generate_vrf, seed): client for client in clients}
        submissions = []
        for future in as_completed(futures):
            client = futures[future]
            try:
                randomness, proof = future.result()
                submission_data = {
                    "client_id": client.id,
                    "randomness": base64.b64encode(randomness).decode(),
                    "proof": base64.b64encode(proof).decode(),
                    "seed": base64.b64encode(seed).decode()
                }
                submissions.append(submission_data)
                upload_counter.add_traffic(json.dumps(submission_data).encode())
            except Exception as e:
                print(f"Client {client.id} VRF generation failed: {e}")

    valid_subs = vrf_server.verify_batch(submissions)

    # 选择Top-K
    k = max(int(frac * len(clients)), 1)
    selected_ids = vrf_server.select_top_k(valid_subs, k)
    print("本轮参与的客户端有:", end=' ')
    for id in selected_ids:
        print(f"{id}", end=' ')

    selected_ids_bytes = json.dumps(selected_ids).encode()
    download_counter.add_traffic(selected_ids_bytes)

    print(f"\nVRF阶段总上传流量: {upload_counter.get_stats('MB'):.4f} MB")
    print(f"VRF阶段总下载流量: {download_counter.get_stats('MB'):.4f} MB")

    return [int(id.split('_')[-1]) for id in selected_ids]  # 转换为原始索引格式


def test_selection():
    server = VRFServer()
    clients = [VRFClient(f"client_{i}") for i in range(100)]
    for c in clients:
        server.register_client(c)
    start = time.time()
    selected = select_clients_vrf_enhanced(server, clients, 0, 0.1)
    print(f"选择客户时间用时{time.time() - start:.2f}s")
    print(f"实际选中数量: {len(selected)}")


if __name__ == "__main__":
    test_selection()
