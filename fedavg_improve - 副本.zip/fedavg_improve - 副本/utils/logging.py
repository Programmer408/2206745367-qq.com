import logging


def setup_logging():
    # 创建根记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    # 统一文件处理器
    file_handler = logging.FileHandler(
        filename='loggings/all_modules.log',
        encoding='utf-8'
    )

    # 设置格式（包含模块名）
    formatter = logging.Formatter(
        '%(asctime)s [%(levelname)-8s] %(name)-25s %(message)s'
    )
    file_handler.setFormatter(formatter)

    root_logger.addHandler(file_handler)
