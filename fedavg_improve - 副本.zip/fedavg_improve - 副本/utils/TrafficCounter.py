class TrafficCounter:
    def __init__(self):
        self.total_bytes = 0

    def add_traffic(self, data):
        """记录通信数据（假设data是字节流）"""
        self.total_bytes += len(data)

    def get_stats(self, unit='MB'):
        """获取统计结果"""
        units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3}
        return self.total_bytes / units[unit]
