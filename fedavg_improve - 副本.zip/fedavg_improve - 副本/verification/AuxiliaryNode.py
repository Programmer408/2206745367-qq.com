import logging
import os
import secrets
import numpy as np
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
from utils.TrafficCounter import TrafficCounter


logger = logging.getLogger(__name__)


class AuxiliaryNode:
    def __init__(self, node_id, num_users, shared_keys):
        self.node_id = node_id
        self.num_users = num_users
        self.shared_keys = shared_keys  # 存储与所有用户的共享密钥
        self.Km = 0.0
        self.alpha_m = 0.0
        self.encrypted_data = {}  # 存储加密后的数据

    def generate_keys(self, selected_users):
        """生成密钥并加密"""

        upload_counter = TrafficCounter()

        # 生成随机参数
        self.Km = sum(
            bytes_to_float(key)
            for (uid, aux_id), key in self.shared_keys.items()
            if aux_id == self.node_id and uid in selected_users # 仅统计本节点的密钥
        )
        self.alpha_m = np.random.rand()

        # 为每个选中用户生成加密数据
        self.encrypted_data.clear()
        for user_id in selected_users:
            # 获取预共享密钥并进行长度适配
            raw_key = self.shared_keys.get((user_id, self.node_id), b'')
            # 将密钥处理为16字节（128位）
            key = raw_key.ljust(16, b'\0')[:16]  # 不足补零，超长截断

            if len(key) < 16:
                key = key.ljust(16, b'\0')  # 补齐到16字节
            elif len(key) > 16:
                key = key[:16]  # 截断到16字节

            # 准备加密数据
            data = f"{self.Km:.8f},{self.alpha_m:.8f}".encode()
            # 使用AES-CBC模式加密
            iv = os.urandom(16)
            padder = padding.PKCS7(128).padder()  # 128对应AES块大小
            padded_data = padder.update(data) + padder.finalize()

            cipher = Cipher(
                algorithms.AES(key),
                modes.CBC(iv)
            ).encryptor()
            ct_bytes = cipher.update(padded_data) + cipher.finalize()
            # 存储加密数据（iv + ciphertext）
            self.encrypted_data[user_id] = iv + ct_bytes

            upload_counter.add_traffic(self.encrypted_data[user_id])  # 统计上传流量
            # print(f"加密数据上传流量: {upload_counter.get_stats('KB'):.2f} KB")
            # logger.info(f"加密数据上传流量: {upload_counter.get_stats('KB'):.2f} KB")

    def get_encrypted_data(self, user_id):
        """获取指定用户的加密数据"""
        return self.encrypted_data.get(user_id, None)

    def get_public_data(self):
        """返回需要传递给用户的数据（模拟加密后的Km和αm）"""
        return {
            'Km': self.Km,
            'alpha_m': self.alpha_m
        }


def generate_shared_keys(num_users, num_auxiliaries):
    """生成用户与辅助节点之间的共享密钥（模拟DH密钥协商）"""
    shared_keys = {}
    key_download_counter = TrafficCounter()
    for user_id in range(num_users):
        for aux_id in range(num_auxiliaries):
            # 使用密码学安全随机数生成16字节（128位）密钥
            key = secrets.token_bytes(16)  # 生成16字节密钥
            shared_keys[(user_id, aux_id)] = key
            # 对应的辅助节点也需要存储相同的密钥（模拟密钥协商）
            # （实际DH实现中双方会生成相同密钥，这里简化为统一存储）
            # 模拟密钥分发流量（假设每个密钥需要上传和下载）
            key_download_counter.add_traffic(key)
            # print(f"密钥分发阶段下载流量: {key_download_counter.get_stats('KB'):.2f} KB")
            # # logger.info(f"密钥分发阶段下载流量: {key_download_counter.get_stats('KB'):.2f} KB")
    return shared_keys


def bytes_to_float(key_bytes):
    """将16字节密钥转换为[0,1)范围内的浮点数"""
    if type(key_bytes) == bytes:
        max_val = 1 << 128  # 2^128
        int_val = int.from_bytes(key_bytes, byteorder='big')
        return int_val / max_val
    else:
        return key_bytes